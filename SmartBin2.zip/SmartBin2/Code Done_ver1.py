import os
import cvzone
from cvzone.ClassificationModule import Classifier
import cv2
import pyttsx3
import threading
import time
import speech_recognition as sr

# Initialize the TTS engine
engine = pyttsx3.init()

# Set properties before adding anything to speak
engine.setProperty('rate', 180)  # Speed percent (can go over 100)
engine.setProperty('volume', 1)  # Volume 0-1

# List available voices and select one by index
voices = engine.getProperty('voices')
for k, v in enumerate(voices):
    print(k, v)

# Change the index to select a different voice
# Here, we select the second voice in the list (index 1) for a potentially higher-pitched voice
engine.setProperty('voice', voices[1].id)

# Create a named window where the mouse callback function will be attached
cv2.namedWindow("Output")

# Create a mouse callback function that checks if the stop button or mic button was clicked
def check_exit(event, x, y, flags, param):
    global recording_name, is_speaking_or_listening
    if event == cv2.EVENT_LBUTTONDOWN:
        # Check if the stop button was clicked
        if 20 <= x <= 120 and 20 <= y <= 120:
            # Set the running flag to False to stop the program
            running[0] = False
        # Check if the mic button was clicked
        if 150 <= x <= 250 and 20 <= y <= 120:
            recording_name = True
            is_speaking_or_listening = True

# Attach the mouse callback function to the window
cv2.setMouseCallback("Output", check_exit)

# Create a flag to indicate if the program is running or not
running = [True]
recording_name = False
name = ""
is_speaking_or_listening = False
is_listening = False
is_recognizing = False
name_display = ""

cap = cv2.VideoCapture(0)
if not cap.isOpened():
    print("Error: Could not open camera.")
    running[0] = False

def speak_greeting():
    global is_speaking_or_listening
    is_speaking_or_listening = True
    # Wait for 5 seconds before speaking
    time.sleep(5)
    engine.say("Hello, My name is Binny! It's great to meet you! In this game, I will help you to distinguish the type of waste. You can put your card near to the camera, and I will distinguish it for you.")
    engine.runAndWait()
    engine.say("Before we start, May I know what's your name?")
    engine.runAndWait()
    is_speaking_or_listening = False

# Start the greeting message in a new thread
greeting_thread = threading.Thread(target=speak_greeting)
greeting_thread.start()

def speak_and_display(text):
    global is_speaking_or_listening
    is_speaking_or_listening = True
    engine.say(text)
    engine.runAndWait()
    is_speaking_or_listening = False

def record_name():
    global name, recording_name, imgBackground, is_speaking_or_listening, is_listening, is_recognizing, name_display
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening...")
        is_listening = True  # Set the listening flag to True
        imgBackground = cv2.imread('Resources/background_buddies.png')
        cv2.putText(imgBackground, "Listening...", (50, imgBackground.shape[0] - 80), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
        cv2.imshow("Output", imgBackground)
        cv2.waitKey(1)
        
        audio = recognizer.listen(source)
        is_listening = False  # Set the listening flag to False
        try:
            print("Recognizing...")
            is_recognizing = True  # Set the recognizing flag to True
            imgBackground = cv2.imread('Resources/background_buddies.png')
            cv2.putText(imgBackground, "Recognizing...", (50, imgBackground.shape[0] - 80), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
            cv2.imshow("Output", imgBackground)
            cv2.waitKey(1)
            
            new_name = recognizer.recognize_google(audio)
            is_recognizing = False  # Set the recognizing flag to False
            print(f"Name recognized: {new_name}")

            # Update the display with the new name
            name = new_name
            name_display = name  # Update the name_display variable
            imgBackground = cv2.imread('Resources/background_buddies.png')
            cv2.putText(imgBackground, f"Hi {name}!", (50, imgBackground.shape[0] - 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
            cv2.imshow("Output", imgBackground)
            cv2.waitKey(1)

            # Now speak the name
            engine.say(f"Hi {name}! Let's play the game. I hope you enjoy this game")
            engine.runAndWait()
        except sr.UnknownValueError:
            print("Could not understand audio")
            speak_and_display("Sorry, I did not understand your name. Please try again.")  # Display error message
        except sr.RequestError as e:
            print(f"Could not request results; {e}")
        recording_name = False
        is_speaking_or_listening = False
        is_listening = False
        is_recognizing = False

classifier = Classifier('Resources/Model3/keras_model.h5', 'Resources/Model3/labels.txt')
imgArrow = cv2.imread('Resources/arrow.png', cv2.IMREAD_UNCHANGED)
classIDBin = 0

# Import all the waste images
imgWasteList = []
pathFolderWaste = "Resources/Waste"
pathList = os.listdir(pathFolderWaste)
for path in pathList:
    img = cv2.imread(os.path.join(pathFolderWaste, path), cv2.IMREAD_UNCHANGED)
    if img is None:
        print(f"Error loading waste image: {path}")
    else:
        imgWasteList.append(img)

# Import all the bin images
imgBinsList = []
pathFolderBins = "Resources/Bins"
pathList = os.listdir(pathFolderBins)
for path in pathList:
    img = cv2.imread(os.path.join(pathFolderBins, path), cv2.IMREAD_UNCHANGED)
    if img is None:
        print(f"Error loading bin image: {path}")
    else:
        imgBinsList.append(img)

classDic = {0: 4,
            1: 0,
            2: 0,
            3: 3,
            4: 3,
            5: 1,
            6: 1,
            7: 2,
            8: 2}

# Main loop
while running[0]:
    _, img = cap.read()
    imgResize = cv2.resize(img, (454, 340))

    imgBackground = cv2.imread('Resources/background_buddies.png')

    if is_listening:
        cv2.putText(imgBackground, "Listening...", (50, imgBackground.shape[0] - 80), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
    elif is_recognizing:
        cv2.putText(imgBackground, "Recognizing...", (50, imgBackground.shape[0] - 80), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
    elif is_speaking_or_listening:
        if name_display:
            cv2.putText(imgBackground, f"Hi {name_display}!", (50, imgBackground.shape[0] - 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
        cv2.putText(imgBackground, "Speaking...", (50, imgBackground.shape[0] - 80), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
    else:
        prediction = classifier.getPrediction(img)
        classID = prediction[1]
        print(classID)
        if classID != 0:
            imgWaste = imgWasteList[classID - 1]
            if imgWaste is not None:
                print(f"Overlay waste image at: (909, 127), shape: {imgWaste.shape}")
                imgBackground = cvzone.overlayPNG(imgBackground, imgWaste, (909, 127))
            else:
                print("Waste image is None")

            if imgArrow is not None:
                print(f"Overlay arrow image at: (978, 320), shape: {imgArrow.shape}")
                imgBackground = cvzone.overlayPNG(imgBackground, imgArrow, (978, 320))
            else:
                print("Arrow image is None")

            classIDBin = classDic[classID]

            binImage = imgBinsList[classIDBin]
            if binImage is not None:
                print(f"Overlay bin image at: (895, 374), shape: {binImage.shape}")
                imgBackground = cvzone.overlayPNG(imgBackground, binImage, (895, 374))
            else:
                print("Bin image is None")
        else:
            classIDBin = -1

        h, w = imgResize.shape[:2]
        print(f"Resize image shape: {imgResize.shape}")
        print(f"Background shape: {imgBackground.shape}")
        imgBackground[148:148 + h, 159:159 + w] = imgResize

        # Display the name if available
        if name_display:
            cv2.putText(imgBackground, f"Hi {name_display}!", (50, imgBackground.shape[0] - 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

    # Draw the stop button
    cv2.circle(imgBackground, (70, 70), 50, (0, 0, 255), -1)
    cv2.putText(imgBackground, "STOP", (30, 85), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)

    # Draw the mic button
    cv2.circle(imgBackground, (200, 70), 50, (255, 0, 0), -1)
    cv2.putText(imgBackground, "MIC", (170, 85), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)

    # Display the resulting frame
    cv2.imshow("Output", imgBackground)
    cv2.waitKey(1)

    if recording_name:
        record_name()

# When everything done, release the capture and destroy the windows
cap.release()
cv2.destroyAllWindows()
